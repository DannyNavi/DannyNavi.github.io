import React from "react";
import './clientbookstyles.css' 

function ClientBook(){

    return(
        <div className="ClientBookContainer">
            <h1>Client Book</h1>
        </div>
    )

}

export default ClientBook